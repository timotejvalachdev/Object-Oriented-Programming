import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


// Zadanie SkuskoveZadanie OOP
// Timotej Valach
//Osobne cislo UIS: 22820


public class SkuskoveZadanie extends JFrame {

    private final JTextField displayField; // Zobrazenie pre zadávanie a výsledok
    private int firstOperand = 0; // Prvý operand
    private int secondOperand = 0; // Druhý operand
    private String operator = ""; // Aktuálna operácia
    private boolean isSecondOperand = false; // Indikácia zadávania druhého operandu

    public SkuskoveZadanie() {
        setTitle("Jednoduchá kalkulačka");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Zobrazenie
        displayField = new JTextField();
        displayField.setEditable(false);
        displayField.setFont(new Font("Arial", Font.BOLD, 24));
        displayField.setHorizontalAlignment(JTextField.RIGHT);
        add(displayField, BorderLayout.NORTH);

        // Tlačidlá kalkulačky
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 4, 5, 5));

        String[] buttons = {
                "7", "8", "9", "+",
                "4", "5", "6", "-",
                "1", "2", "3", "*",
                "+/-", "0", "C", "="
        };

        for (String text : buttons) {
            JButton button = new JButton(text);
            button.setFont(new Font("Arial", Font.BOLD, 18));

            // Nastavenie farby tlačidiel
            if (text.matches("\\d")) { // Čísla
                button.setBackground(Color.LIGHT_GRAY);
            } else { // Operácie a špeciálne tlačidlá
                button.setBackground(Color.ORANGE);
            }
            button.setOpaque(true);
            button.setBorderPainted(false);

            button.addActionListener(new ButtonClickListener());
            buttonPanel.add(button);
        }

        add(buttonPanel, BorderLayout.CENTER);
    }

    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = ((JButton) e.getSource()).getText();

            if (command.matches("\\d")) { // Číslice
                if (isSecondOperand) {
                    displayField.setText("");
                    isSecondOperand = false;
                }
                displayField.setText(displayField.getText() + command);
            } else if (command.equals("C")) { // Vymazanie
                firstOperand = 0;
                secondOperand = 0;
                operator = "";
                isSecondOperand = false;
                displayField.setText("");
            } else if (command.equals("+/-")) { // Zmena znamienka
                String currentText = displayField.getText();
                if (!currentText.isEmpty()) {
                    int value = Integer.parseInt(currentText);
                    displayField.setText(String.valueOf(-value));
                }
            } else if (command.equals("=")) { // Výpočet
                if (!operator.isEmpty() && !displayField.getText().isEmpty()) {
                    secondOperand = Integer.parseInt(displayField.getText());
                    int result = calculate(firstOperand, secondOperand, operator);
                    displayField.setText(String.valueOf(result));
                    operator = "";
                }
            } else { // Operácie +, -, *
                if (!displayField.getText().isEmpty()) {
                    firstOperand = Integer.parseInt(displayField.getText());
                    operator = command;
                    isSecondOperand = true;
                }
            }
        }

        private int calculate(int a, int b, String operator) {
            return switch (operator) {
                case "+" -> a + b;
                case "-" -> a - b;
                case "*" -> a * b;
                default -> 0;
            };
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SkuskoveZadanie calculator = new SkuskoveZadanie();
            calculator.setVisible(true);
        });
    }
}
