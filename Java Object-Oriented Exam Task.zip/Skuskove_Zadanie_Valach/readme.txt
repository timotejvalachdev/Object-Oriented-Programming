

Navod na spustenie:

Najprv skompilujeme prikazom javac SkuskoveZadanie.java
Spustime prikazom: java SkuskoveZadanie