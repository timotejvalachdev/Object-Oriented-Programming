


Navod na spustenie:

Najprv skompilujeme prikazom javac Zadanie2.java

Note: Zadanie2.java uses unchecked or unsafe operations“
Toto je varovanie, nie chyba. Ak chcete detaily, kompiluj s voľbou.

Kod je funkncny a da sa spustit.

Spustime prikazom: java Zadanie2