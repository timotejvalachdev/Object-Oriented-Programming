import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

// Zadanie 2 OOP
// Timotej Valach
//Osobne cislo UIS: 22820


// Trieda pre reprezentáciu úsečky
class Line implements Serializable {
    private final Point start; // Začiatok úsečky (počiatočný bod)
    private final Point end; // Koniec úsečky (koncový bod)
    private final Color color; // Farba úsečky

    public Line(Point start, Point end, Color color) {
        this.start = start;
        this.end = end;
        this.color = color;
    }

    public Point getStart() {
        return start;
    }

    public Point getEnd() {
        return end;
    }

    public Color getColor() {
        return color;
    }
}

public class Zadanie2 extends JFrame {
    private final ArrayList<Line> lines = new ArrayList<>(); // Množina nakreslených úsečiek
    private Point startPoint = null; // Počiatočný bod aktuálnej úsečky
    private Color selectedColor = Color.RED; // Predvolená farba

    public Zadanie2() {
        setTitle("Kreslenie úsečiek");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel pre výber farieb
        JPanel colorPanel = new JPanel();
        JButton redButton = createColorButton("Červená", Color.RED);
        JButton greenButton = createColorButton("Zelená", Color.GREEN);
        JButton blueButton = createColorButton("Modrá", Color.BLUE);
        JButton clearButton = new JButton("Vymazať"); // Tlačidlo na vymazanie kreslenia

        clearButton.addActionListener(e -> {
            lines.clear(); // Vyčisti zoznam úsečiek
            repaint(); // Aktualizuj kresliaci panel
        });

        colorPanel.add(redButton);
        colorPanel.add(greenButton);
        colorPanel.add(blueButton);
        colorPanel.add(clearButton);

        add(colorPanel, BorderLayout.NORTH);

        // Kresliaci panel
        DrawingPanel drawingPanel = new DrawingPanel();
        add(drawingPanel, BorderLayout.CENTER);

        // Menu pre ukladanie a načítavanie
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("Súbor");
        JMenuItem saveItem = new JMenuItem("Uložiť");
        JMenuItem loadItem = new JMenuItem("Načítať");

        saveItem.addActionListener(e -> saveToFile());
        loadItem.addActionListener(e -> loadFromFile());

        fileMenu.add(saveItem);
        fileMenu.add(loadItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
    }

    private JButton createColorButton(String name, Color color) {
        JButton button = new JButton(name);
        button.setBackground(color);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.addActionListener(e -> selectedColor = color);
        return button;
    }

    private void saveToFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
                out.writeObject(lines);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Chyba pri ukladaní súboru.", "Chyba", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadFromFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
                lines.clear();
                lines.addAll((ArrayList<Line>) in.readObject());
                repaint();
            } catch (IOException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, "Chyba pri načítavaní súboru.", "Chyba", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private class DrawingPanel extends JPanel {
        public DrawingPanel() {
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    startPoint = e.getPoint(); // Uloženie počiatočného bodu
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    if (startPoint != null) {
                        Point endPoint = e.getPoint(); // Uloženie koncového bodu
                        lines.add(new Line(startPoint, endPoint, selectedColor)); // Pridanie úsečky
                        startPoint = null;
                        repaint();
                    }
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    if (startPoint != null) {
                        Point currentPoint = e.getPoint();
                        repaint();
                        Graphics g = getGraphics();
                        g.setColor(selectedColor);
                        g.drawLine(startPoint.x, startPoint.y, currentPoint.x, currentPoint.y);
                    }
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            for (Line line : lines) {
                g.setColor(line.getColor());
                g.drawLine(line.getStart().x, line.getStart().y, line.getEnd().x, line.getEnd().y);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Zadanie2 app = new Zadanie2();
            app.setVisible(true);
        });
    }
}
